// Funciones para manejar los botones
function handleLogin() {
    console.log('Iniciando sesión...');
    // Aquí puedes agregar la lógica para el login
    alert('Función de inicio de sesión - Próximamente');
}

function handleRegister() {
    console.log('Registrando usuario...');
    // Aquí puedes agregar la lógica para el registro
    alert('Función de registro - Próximamente');
}

// Animaciones suaves para los botones
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
        
        button.addEventListener('mousedown', function() {
            this.style.transform = 'translateY(0)';
        });
        
        button.addEventListener('mouseup', function() {
            this.style.transform = 'translateY(-2px)';
        });
    });
});